# نظام إدارة الموظفين - Employee Management System

تطبيق موبايل عربي لإدارة بيانات الموظفين مبني بـ React Native (Expo) و FastAPI

## 📦 محتويات الملف
- `backend/` - خادم FastAPI
- `frontend/` - تطبيق Expo React Native

## 🔐 بيانات الدخول الافتراضية
- **اسم المستخدم:** zahab
- **كلمة المرور:** 9999

## 🛠️ التثبيت

### 1. تثبيت Python و MongoDB
- Python: https://www.python.org/downloads/
- MongoDB: https://www.mongodb.com/try/download/community

### 2. تشغيل Backend
```bash
cd backend
pip install -r requirements.txt
# أو
python -m pip install -r requirements.txt

# إنشاء ملف .env
copy .env.example .env

# تشغيل الخادم
python -m uvicorn server:app --host 0.0.0.0 --port 8001
```

### 3. تشغيل Frontend
```bash
cd frontend
npm install --legacy-peer-deps

# إنشاء ملف .env
copy .env.example .env
# عدّل EXPO_PUBLIC_BACKEND_URL

# تشغيل التطبيق
npx expo start
```

## 📱 بناء APK

```bash
cd frontend
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```

## ✨ المميزات
- إدارة بيانات الموظفين (الاسم، الرتبة، الأقدمية، الهاتف، العمل المسند، القطاع، الصورة)
- 3 مستويات صلاحيات (مدير النظام، مدير، مستخدم)
- البحث والفلترة
- تصدير PDF و Excel
- دعم البصمة
- واجهة عربية بالكامل

## 📞 التواصل
تصميم مقدم د. / رامي ابو الذهب

---
منطقة شرق الدلتا
