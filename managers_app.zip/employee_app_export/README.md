# نظام إدارة الموظفين - Employee Management System

تطبيق موبايل عربي لإدارة بيانات الموظفين مبني بـ React Native (Expo) و FastAPI

## 📋 المميزات

- ✅ تسجيل الدخول بكلمة المرور والبصمة
- ✅ إدارة بيانات الموظفين (الاسم، الرتبة، الأقدمية، الهاتف، العمل المسند، القطاع، الصورة)
- ✅ 3 مستويات صلاحيات (مدير النظام، مدير، مستخدم)
- ✅ إدارة القطاعات
- ✅ البحث والفلترة
- ✅ تصدير PDF و Excel
- ✅ طباعة التقارير
- ✅ تخصيص العنوان والتذييل والشعار

## 🔐 بيانات الدخول الافتراضية

- **اسم المستخدم:** zahab
- **كلمة المرور:** 9999

## 🛠️ التثبيت والتشغيل

### Backend (FastAPI)

```bash
cd backend
pip install -r requirements.txt

# إنشاء ملف .env
cp .env.example .env
# عدّل MONGO_URL حسب إعدادات MongoDB لديك

# تشغيل الخادم
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Frontend (Expo)

```bash
cd frontend
npm install
# أو
yarn install

# إنشاء ملف .env
cp .env.example .env
# عدّل EXPO_PUBLIC_BACKEND_URL إلى عنوان الخادم

# تشغيل التطبيق
npx expo start
```

## 📱 بناء APK

```bash
cd frontend

# تثبيت EAS CLI
npm install -g eas-cli

# تسجيل الدخول
eas login

# إعداد البناء
eas build:configure

# بناء APK
eas build --platform android --profile preview
```

## 📁 هيكل المشروع

```
├── backend/
│   ├── server.py          # FastAPI server
│   ├── requirements.txt   # Python dependencies
│   └── .env              # Environment variables
│
├── frontend/
│   ├── app/              # Expo Router screens
│   │   ├── _layout.tsx   # Root layout
│   │   ├── index.tsx     # Login screen
│   │   ├── home.tsx      # Employee list
│   │   ├── add-employee.tsx
│   │   ├── employee-details.tsx
│   │   ├── settings.tsx
│   │   ├── manage-users.tsx
│   │   ├── manage-sectors.tsx
│   │   ├── app-settings.tsx
│   │   ├── report.tsx
│   │   └── export.tsx
│   ├── assets/           # Images and fonts
│   ├── app.json          # Expo config
│   └── package.json      # Dependencies
```

## 🔧 المتطلبات

- Node.js 18+
- Python 3.9+
- MongoDB
- Expo CLI

## 📞 التواصل

تصميم مقدم د. / رامي ابو الذهب

---
منطقة شرق الدلتا
